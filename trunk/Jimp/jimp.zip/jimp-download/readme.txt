Ngantuk!

Taufik, 4 Juni 2012